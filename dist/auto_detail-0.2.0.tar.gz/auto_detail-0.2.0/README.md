# auto-detail

A CLI tool for automatically detailing software development projects.

`auto-detail` is a command-line utility designed to streamline the process of documenting your software development workflow. By recording small, atomic "details" about the changes you make, it can then leverage AI to generate formatted commit messages and even update your project's README file.

## Features

- **Simple Detailing**: Quickly record notes about your work from the command line.
- **AI-Powered Commit Messages**: Generate well-structured commit messages based on your recorded details.
- **Automatic README Generation**: Create or update a README file that summarizes your project's progress.
- **Local Storage**: All details are stored locally in simple YAML files.

## Installation

This project is managed with [Poetry](https://python-poetry.org/).

1.  **Install dependencies:**
    ```bash
    poetry install
    ```

2.  **Set up your environment:**
    Create a `.env` file in the project root and add your OpenAI API key. This is required for features that generate text.
    ```
    OPENAI_API_KEY="your-openai-api-key-here"
    ```

## Usage

All commands are run through the `detail` CLI entrypoint, which is invoked via `poetry run`.

### Initialize the Project
Before first use, you must initialize the project to create the `.detail/notes` directory.
```bash
poetry run detail init
```

### Create a New Detail
The `new` command is your primary tool for logging progress. It captures a single, atomic unit of work.
```bash
poetry run detail new "Your detailed description of the work done."
```
This creates a timestamped YAML file in the `.detail/notes/` directory containing your note. These details are used by other commands.

### View Details
To see a list of all recorded details:
```bash
poetry run detail show
```

### Generate a Commit Message
To generate a conventional commit message based on your recorded details:
```bash
poetry run detail generate-commit
```
